package com.etc.jn.dao;

public interface CommentsDao {
}
