package com.etc.jn.dto;

public class FansCount {
    private Integer fansnumber;

    public Integer getFansnumber() {
        return fansnumber;
    }

    public void setFansnumber(Integer fansnumber) {
        this.fansnumber = fansnumber;
    }
}
