package com.etc.jn.service;

public interface User_typeService {
}
