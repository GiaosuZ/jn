package com.etc.jn.vo;

public class Useremailvo {
    private String jn_useremail;

    public String getJn_useremail() {
        return jn_useremail;
    }

    public void setJn_useremail(String jn_useremail) {
        this.jn_useremail = jn_useremail;
    }
}
