package com.etc.jn.dao;

public interface User_typeDao {
}
