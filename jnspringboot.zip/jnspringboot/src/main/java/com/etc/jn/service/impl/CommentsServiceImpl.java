package com.etc.jn.service.impl;

import com.etc.jn.service.CommentsService;
import org.springframework.stereotype.Service;

@Service
public class CommentsServiceImpl implements CommentsService {
}
