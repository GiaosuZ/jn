package com.etc.jn.dao;

public interface FansDao {
}
