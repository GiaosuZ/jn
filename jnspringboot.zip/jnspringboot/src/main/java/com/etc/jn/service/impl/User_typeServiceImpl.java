package com.etc.jn.service.impl;

import com.etc.jn.service.User_typeService;
import org.springframework.stereotype.Service;

@Service
public class User_typeServiceImpl implements User_typeService {
}
