package com.etc.jn.vo;

public class Postidvo {
    private  Integer jn_postid;

    public Integer getJn_postid() {
        return jn_postid;
    }

    public void setJn_postid(Integer jn_postid) {
        this.jn_postid = jn_postid;
    }
}
