package com.etc.jn.service.impl;

import com.etc.jn.service.FansService;
import org.springframework.stereotype.Service;

@Service
public class FansServiceImpl implements FansService {
}
