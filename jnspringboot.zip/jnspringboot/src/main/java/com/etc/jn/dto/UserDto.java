package com.etc.jn.dto;

public class UserDto {
    private  Integer jn_userid;  //用户id
    private  String jn_username; //用户名字
    private  String jn_userpwd; // 用户密码
    private String jn_usertel;  //用户电话号码
    private String jn_email; //用户邮箱
    private  String jn_userstatus; //用户状态
    private  String jn_userlogo;  //用户头像
    private  String jn_usersex;   //用户性别
    private String jn_usersigature; //个性签名
    private Integer code;

    public Integer getJn_userid() {
        return jn_userid;
    }

    public void setJn_userid(Integer jn_userid) {
        this.jn_userid = jn_userid;
    }

    public String getJn_username() {
        return jn_username;
    }

    public void setJn_username(String jn_username) {
        this.jn_username = jn_username;
    }

    public String getJn_userpwd() {
        return jn_userpwd;
    }

    public void setJn_userpwd(String jn_userpwd) {
        this.jn_userpwd = jn_userpwd;
    }

    public String getJn_usertel() {
        return jn_usertel;
    }

    public void setJn_usertel(String jn_usertel) {
        this.jn_usertel = jn_usertel;
    }

    public String getJn_email() {
        return jn_email;
    }

    public void setJn_email(String jn_email) {
        this.jn_email = jn_email;
    }

    public String getJn_userstatus() {
        return jn_userstatus;
    }

    public void setJn_userstatus(String jn_userstatus) {
        this.jn_userstatus = jn_userstatus;
    }

    public String getJn_userlogo() {
        return jn_userlogo;
    }

    public void setJn_userlogo(String jn_userlogo) {
        this.jn_userlogo = jn_userlogo;
    }

    public String getJn_usersex() {
        return jn_usersex;
    }

    public void setJn_usersex(String jn_usersex) {
        this.jn_usersex = jn_usersex;
    }

    public String getJn_usersigature() {
        return jn_usersigature;
    }

    public void setJn_usersigature(String jn_usersigature) {
        this.jn_usersigature = jn_usersigature;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
