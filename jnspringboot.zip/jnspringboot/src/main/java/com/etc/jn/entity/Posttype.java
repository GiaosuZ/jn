package com.etc.jn.entity;

public class Posttype {
    private Integer jn_posttypeid; //标签id
    private String jn_posttypename;  //标签、类型名

    public Integer getJn_posttypeid() {
        return jn_posttypeid;
    }

    public void setJn_posttypeid(Integer jn_posttypeid) {
        this.jn_posttypeid = jn_posttypeid;
    }

    public String getJn_posttypename() {
        return jn_posttypename;
    }

    public void setJn_posttypename(String jn_posttypename) {
        this.jn_posttypename = jn_posttypename;
    }
}
