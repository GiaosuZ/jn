package com.etc.jn.service.impl;

import com.etc.jn.service.HistoryService;
import org.springframework.stereotype.Service;

@Service
public class HistoryServiceImpl implements HistoryService {
}
